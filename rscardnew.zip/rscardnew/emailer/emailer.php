<?php
$to = 'punit@dynakode.com';
$subject ='hello';
$from = 'demoavailable.com';
$body ="hello";
if(mail($to, "$subject", $body, "$from")){
	echo "sent successfully";
}
?>