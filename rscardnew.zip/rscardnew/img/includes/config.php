<?php
define('SITEURL','http://click.dynakode.com');
date_default_timezone_set('Asia/Kolkata');
define('DS',DIRECTORY_SEPARATOR);
define('IP',$_SERVER['REMOTE_ADDR']);
define('SITEPATH',$_SERVER['DOCUMENT_ROOT']);
define('UPLOAD',SITEPATH.DS.'uploads');

//// Status for opportunity ////

$allStatus = array('Fresh','Qualified','Requirement Gathering','Proposal Sent','Won','Closed','Rejected');




