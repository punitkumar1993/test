<?php
if(!in_array($_SESSION['user']['role'], $allowedUser)){
	header('location:authetication.php');
	exit;
}