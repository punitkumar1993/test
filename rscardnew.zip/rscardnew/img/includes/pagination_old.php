<?php
function pagination_link($page_num, $search)
{	
	if(strpos($_SERVER['REQUEST_URI'], '?')){
		$part = explode("?", $_SERVER['REQUEST_URI']);
		$requestUrl = $part[0];
	}
	else
		$requestUrl = $_SERVER['REQUEST_URI'];
	
	if(!empty($search))
		return $requestUrl."?search=".$search."&page=".$page_num;
	else
		return $requestUrl."?page=".$page_num;
		
}

function pagination($total_pages, $page_num, $max_links)
{	
	$firstClass = '';
	if($page_num  >  1){
			$first = '<li class="paginate_button '.$firstClass.'" >
							<a href="'.pagination_link($page_num-1).'">Previous</a>
						</li>';
			$prev = '<li class="paginate_button '.$firstClass.'" >
						<a href="'.pagination_link(1).'">First</a>
					</li>';	
		echo $first.$prev;
	}	
	$next = '';
	$last = '';
	$lastClass = '';
	if($page_num < $total_pages)
	{ 
		$next = '<li class="paginate_button '.$lastClass.'" >
							<a href="'.pagination_link($page_num+1).'">Next</a>
						</li>';
		$last = '<li class="paginate_button '.$lastClass.'" >
							<a href="'.pagination_link($total_pages).'">Last</a>
						</li>';	
	}	
	
	
	$loop = 0;
	if($page_num >= $max_links) 
	{
		$page_counter = ceil($page_num - ($max_links-1));
	} 
	else 
	{
		$page_counter = 1;
	}
	
	if($total_pages < $max_links)
	{
		$max_links = $total_pages;
	}	
	do
	{ 
		if($page_counter == $page_num) 
		{
		    echo '<li class="paginate_button active"><a href="javascript:void(0);">'.$page_counter.'</a></li>'; 
		} 
		else
		{
			echo '<li class="paginate_button"><a href="'.pagination_link(($page_counter), $search).'" >'.$page_counter.'</a></li>';
		} 
		$page_counter++; $current_page=($page_counter+1);
		$loop++;
	} 
	while 
    ($max_links > $loop);
		echo $next.$last;
}
?>