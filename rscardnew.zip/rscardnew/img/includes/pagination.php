<?php
function pagination_link($page_num, $search)
{	
	$queryString = $_SERVER['QUERY_STRING'];
	if(strpos($_SERVER['REQUEST_URI'], '?')){
		$part = explode("?", $_SERVER['REQUEST_URI']);
		$requestUrl = $part[0];
	}
	else
		$requestUrl = $_SERVER['REQUEST_URI'];

	$newQueryString = "";
	if(!empty($queryString)){
		
		$part = explode("&", $queryString);
		foreach($part as $p){
			if(strpos($p, "page") === false){
				$newQueryString = $newQueryString."&".$p; 
			}
		}
	}
	$newQueryString = trim($newQueryString, "&");
	if(!empty($newQueryString)){
		$newQueryString = $newQueryString."&page=".$page_num;
	}else{
		$newQueryString = "page=".$page_num; 
	}
	return $requestUrl."?".$newQueryString;
	// if(!empty($search))
	// 	return $requestUrl."?search=".$search."&page=".$page_num;
	// else
	// 	return $requestUrl."?page=".$page_num;
		
}

function pagination($total_pages, $page_num, $max_links, $search="")
{
	if($page_num >1){
		$firstClass = "previous paginate_button";
		$first = '<li id="" class="'.$firstClass.'" aria-controls="products-table" tabindex="0"><a href="'.pagination_link(1, $search).'" >First</a></li>';
		$prev = '<li class="'.$firstClass.'" aria-controls="products-table" tabindex="0"><a href="'.pagination_link($page_num -1, $search).'">Prev</a></li>';	
	}	
	echo $first.$prev;
	if($page_num < $total_pages)
	{ 
		$lastClass = "previous paginate_button";		
		$next = '<li class="'.$lastClass.'" aria-controls="products-table" tabindex="0"><a href="'.pagination_link($page_num+1, $search).'" >Next</a></li>';
		$last = '<li class="'.$lastClass.'" aria-controls="products-table" tabindex="0"><a href="'.pagination_link($total_pages, $search).'" >Last</a></li>';
	}
	
	$loop = 0;
	if($page_num >= $max_links) 
	{
		$page_counter = ceil($page_num - ($max_links-1));
	} 
	else 
	{
		$page_counter = 1;
	}
	
	if($total_pages < $max_links)
	{
		$max_links = $total_pages;
	}	
	do
	{ 
		if($page_counter == $page_num) 
		{
		    echo '<li class="paginate_button active" aria-controls="products-table" tabindex="0"><a href="javascript:void(0);" class="paginate_active">'.$page_counter.'</a></li>'; 
		} 
		else
		{
			echo '<li class="paginate_button" aria-controls="products-table" tabindex="0"><a href="'.pagination_link(($page_counter), $search).'" class="paginate_button">'.$page_counter.'</a></li>';
		} 
		$page_counter++; $current_page=($page_counter+1);
		$loop++;
	} 
	while 
    ($max_links > $loop);
		echo $next.$last;
}
?>