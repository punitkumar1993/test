<?php
include('../includes/functions.php');
include('../includes/connect.php');
if(isset($_POST['email'])){
	$name = $_POST['name'];
	$email = $_POST['email'];
	$subject = $_POST['subject'];
	$message = $_POST['message'];
	echo $name;
}
// echo "hello";
// echo $email;
// $email ='punit@dynakode.com';
// $name='punit';

			$mailbody = file_get_contents("../emailer/emailer.html");
			$mailbody = str_replace("[Name]", $name, $mailbody);
			$mailbody = str_replace("[Email]", $email, $mailbody);
			$mailbody = str_replace("[Subject]", $subject, $mailbody);
			$mailbody = str_replace("[Message]", $message, $mailbody);
			// $subject   =   $_POST['subject'];
			$headers    =   'MIME-Version: 1.0' . "\r\n";
    	    $headers   .=   'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    		$headers   .=   'From: Coolbiz <'.$email.'>' . "\r\n";
    		// $headers   .=   'From: DCRM <no-reply@dynakode.com>' . "\r\n";
           if(mail('mr.punitkumar1993@gmail.com', $subject, $mailbody, $headers))
           {
           	echo "sent mail successfully";
           }

?>