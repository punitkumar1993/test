<?php
include('../connect.php');
include('../functions.php');
date_default_timezone_set("Asia/calcutta");
if(isset($_POST['rs-comment-message'])){
	$name = $_POST['rs-comment-name'];
	$email = $_POST['rs-comment-email'];
	$subject = $_POST['rs-comment-website'];
	$message = $_POST['rs-comment-message'];
	$addarray = array();
	$addarray['username'] = $name;
	$addarray['email'] = $email;
	$addarray['subject'] = $subject;
	$addarray['comment'] = $message;
	$addarray['createddate'] = time();
	// if(addData('tbl_comment', $addarray)){
	// 	echo "added successfully";
	// }
	if(addData('tbl_comment', $addarray)){
		echo "add successfully";
		if($email!='mr.punitkumar1993@gmail.com'){
		$mailbody = file_get_contents("../emailer/comment.html");
			$mailbody = str_replace("[Name]", $name, $mailbody);
			$mailbody = str_replace("[Email]", $email, $mailbody);
			$mailbody = str_replace("[Subject]", $subject, $mailbody);
			$mailbody = str_replace("[Comment]", $message, $mailbody);
			// $subject   =   $_POST['subject'];
			$headers    =   'MIME-Version: 1.0' . "\r\n";
    	    $headers   .=   'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    		$headers   .=   'From: Coolbiz <'.$email.'>' . "\r\n";
    		// $headers   .=   'From: DCRM <no-reply@dynakode.com>' . "\r\n";
           if(mail('mr.punitkumar1993@gmail.com', $subject, $mailbody, $headers))
           {
           	echo "sent mail successfully";
           	$phone = '7301201988';
           	if(sendSMS($phone, $message)){
           		echo 'msg send';
           	}
           }
       }

	}
}
?>