								<?php
									// $allowedUser = array('admin');
									include('functions.php');
									include('connect.php');

                                   

									$query = "SELECT  username, createddate,  comment FROM tbl_comment";

									$counter = 0;
									$data  = fetchData($query,array(),$counter);

									$query1 = "SELECT count(username) as countcomment FROM tbl_comment";

									$counter1 = 0;
									$data1  = fetchData($query1,array(),$counter1);

									// echo $query;
                          ?>
<!DOCTYPE html>
<html lang="en" class=" theme-color-33d685 theme-skin-light">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>RScard</title>

	<!-- Favicon -->
	<link rel="shortcut icon" type="image/ico" href="img/favicon.png"/>

	<!-- Google Fonts -->
	<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Fredoka+One">
	<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic">

	<!-- Icon Fonts -->
	<link rel="stylesheet" type="text/css" href="fonts/map-icons/css/map-icons.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/icomoon/style.css">

	<!-- Styles -->
	<link rel="stylesheet" type="text/css" href="js/plugins/jquery.bxslider/jquery.bxslider.css">
	<link rel="stylesheet" type="text/css" href="js/plugins/jquery.customscroll/jquery.mCustomScrollbar.min.css">
	<link rel="stylesheet" type="text/css" href="js/plugins/jquery.mediaelement/mediaelementplayer.min.css">
	<link rel="stylesheet" type="text/css" href="js/plugins/jquery.fancybox/jquery.fancybox.css">
	<link rel="stylesheet" type="text/css" href="js/plugins/jquery.optionpanel/option-panel.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="colors/theme-color.css">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

	<!-- Modernizer for detect what features the user’s browser has to offer -->
	 <!-- <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.9/angular.min.js"></script> -->
	<script type="text/javascript" src="js/libs/modernizr.js"></script>
	
</head>

<body class="page-single header-has-img loading">


    <div class="mobile-nav">
        <button class="btn-mobile mobile-nav-close"><i class="icon icon-close"></i></button>
		
        <div class="mobile-nav-inner">
            <nav class="nav">
				<ul class="clearfix">
					<li><a href="index.html#about">About</a></li>
					<li><a href="index.html#skills">Skills</a></li>
					<li><a href="index.html#portfolio">Portfolio</a> </li>
					<li><a href="index.html#experience">Experience</a></li>
					<li><a href="index.html#references">References</a></li>
					<li>
						<a href="category.html">Blog</a>
						<ul>
							<li><a href="single-image.html">Image Post</a></li>
							<li><a href="single-slider.html">Slider Post</a></li>
							<li><a href="single-video.html">Video Post</a></li>
							<li><a href="single-audio.html">Audio Post</a></li>
							<li><a href="single-vimeo.html">Vimeo Post</a></li>
							<li><a href="single-youtube.html">Youtube Post</a></li>
							<li><a href="single-dailymotion.php">Dailymotion Post</a></li>
							<li><a href="single.html">Without Media Post</a></li>
							<li><a href="typography.html">Typography Page</a></li>
							<li><a href="404.html">404 Page</a></li>
						</ul>
					</li>
					<li><a href="index.html#calendar">Calendar <span></span></a></li>
					<li><a href="index.html#contact">Contact <span></span></a></li>
				</ul>
			</nav>
        </div>
    </div><!-- .mobile-nav -->    

    <div class="wrapper">
        <header class="header">
            <div class="head-bg" style="background-image: url('img/uploads/rs-cover.jpg')"></div>

            <div class="head-bar">
                <div class="head-bar-inner">
                    <div class="row">
                        <div class="col-sm-3 col-xs-6">                            
                            <a class="logo" href="index.html"><span>RS</span>card</a>
							<!-- <a class="head-logo" href=""><img src="img/rs-logo.png" alt="RScard"/></a> -->
                        </div>

                        <div class="col-sm-9 col-xs-6">
                            <div class="nav-wrap">
                                <nav class="nav">
									<ul class="clearfix">
										<li><a href="index.html#about">About</a></li>
										<li><a href="index.html#skills">Skills</a></li>
										<li><a href="index.html#portfolio">Portfolio</a> </li>
										<li><a href="index.html#experience">Experience</a></li>
										<li><a href="index.html#references">References</a></li>
										<li>
											<a href="category.html">Blog</a>
											<ul>
												<li><a href="single-image.html">Image Post</a></li>
												<li><a href="single-slider.html">Slider Post</a></li>
												<li><a href="single-video.html">Video Post</a></li>
												<li><a href="single-audio.html">Audio Post</a></li>
												<li><a href="single-vimeo.html">Vimeo Post</a></li>
												<li><a href="single-youtube.html">Youtube Post</a></li>
												<li><a href="single-dailymotion.php">Dailymotion Post</a></li>
												<li><a href="single.html">Without Media Post</a></li>
												<li><a href="typography.html">Typography Page</a></li>
												<li><a href="404.html">404 Page</a></li>
											</ul>
										</li>
										<li><a href="index.html#calendar">Calendar <span></span></a></li>
										<li><a href="index.html#contact">Contact <span></span></a></li>
									</ul>
								</nav>

                                <button class="btn-mobile btn-mobile-nav">Menu</button>
                                <button class="btn-sidebar btn-sidebar-open"><i class="icon icon-menu"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header><!-- .header -->

        <div class="content">
            <div class="container">

			<!-- START: PAGE CONTENT -->			
			<div class="row animate-up">
				<div class="col-sm-8">
					<main class="post-single">
						<article class="post-content section-box">
							<div class="post-media">
								<div class="post-embed">
                                    <iframe class="post-embed-item" src="http://www.bing.com/videos/search?q=embed+video+of+anupam+kher+speech&view=detail&mid=BDCA5BD4A4497DBD0424BDCA5BD4A4497DBD0424&FORM=VIRE" allowfullscreen></iframe>                    
                                </div>						
							</div><!-- .post-media -->

							<div class="post-inner">
								<header class="post-header">
									<div class="post-data">
										<div class="post-tag">
											<a href="">#Photo</a>
											<a href="">#Architect</a>
										</div>

										<div class="post-title-wrap">
											<h1 class="post-title">Anupam Kher's fiery speech going viral! </h1>
											<time class="post-datetime" datetime="2015-03-13T07:44:01+00:00">
												<span class="day">06</span>
												<span class="month">March</span>
											</time>
										</div>

										<div class="post-info">
											<a href=""><i class="icon icon-user"></i>by admin</a>
											<a href=""><i class="icon icon-comments"></i>56</a>
										</div>
									</div>
								</header>

								<div class="post-editor clearfix">
									<p>New Delhi: Various social media websites are abuzz with Anupam Kher's fiery speech going viral! <br/>
										That no one can stop them. </p>

									<p>In the video, angry Anupam Kher is slamming those behind Afzal Guru's event in JNU where - 'Bharat tere tukde honge, Inshallah..Inshallah' and 'Afzal hum sharminda hain, tere kaatil zinda hain' and the like slogans were raised.</p>
									<blockquote>
										<p>"This is a no debate. The rich and the famous are talking of intolerance. If you ask a man on the street, they won’t talk about intolerance. All they want is food two times a day. Those with a champagne in a glass are only talking about it. Are you living in India or America,” Kher said at the Telegraph National Debate on intolerance here"<br>
											<cite><a href="">John Doe</a> - Someone famous in Source Title</cite>
										</p>
									</blockquote>

									<figure id="attachment_905" style="width: 509px;" class="wp-caption alignright">
										<img class="size-full wp-image-905 " title="Image Alignment 509x319"
											 alt="Image Alignment 509x319" src="img/uploads/454877C.gif" width="509"
											 height="319">
										<figcaption class="wp-caption-text">Feels good to be right all the time.</figcaption>
									</figure>

									<p>Kher started by taking on Justice Asok Kumar Ganguly who spoke before him and had called the Supreme Court judgement in Afzal Guru case wrong. “I am shocked, ashamed and saddened by what you said being a judge you say that SC judgement was wrong,” 
										Kher said to Justice Ganguly. 


									</p>

									<h2>He also said that if Congress Vice-President Rahul Gandhi became even one-tenth of what Prime Minister Narendra Modi was, he would vote for him.</h2>

									<ul>
										<li>he did not need to prove his loyalty to her by supporting her party;</li>
										<li>He added that the word intolerance was being marketed and used against PM Modi because there were no other concrete issue to talk about, including corruption;</li>
										<li>People like Yogi and Sadhvi should be jailed and thrown out of BJP .</li>
									</ul>

									<p>Lashing out at Congress leader Randeep Surjewala, who was also a participant in the debate, Kher said that his party was tolerating a person who they are trying to project as the Prime Ministerial candidate. “If you can tolerate that person, then you can tolerate anything in the world,” he said, referring to Rahul Gandhi. </p>
								</div>

								<footer class="post-footer">
									<div class="post-share">
										<script type="text/javascript" src="http://s7.addthis.com/js/300/addthis_widget.js#pubid=ra-503b5cbf65c3f4d8" async="async"></script>
										<div class="addthis_sharing_toolbox"></div>
									</div>
								</footer>
							</div><!-- .post-inner -->
						</article><!-- .post-content -->

						<nav class="post-pagination section-box">
							<div class="post-next">
								<div class="post-tag">Previous Article <a href="">#Narendramodi</a></div>
								<h3 class="post-title"><a href="">Narendra Modi speech at parliament</a></h3>

								<div class="post-info">
									<a href=""><i class="icon icon-user"></i>by admin</a>
									<a href=""><i class="icon icon-comments"></i>60</a>
								</div>
							</div>
							<div class="post-prev">
								<div class="post-tag">Current Article <a href="">#Anupamkherspeech</a></div>
								<h3 class="post-title"><a href="">Anupamkher speech at telegraphh debate</a></h3>

								<div class="post-info">
									<a href=""><i class="icon icon-user"></i>by admin</a>
									<a href=""><i class="icon icon-comments"></i><?php foreach($data1 as $value) { echo $value['countcomment']; }?></a>
								</div>
							</div>
						</nav><!-- .post-pagination -->

						<div class="post-comments">
							<h2 class="section-title">Comments (<?php foreach($data1 as $value) { echo $value['countcomment']; }?>)</h2>
							
							<div class="section-box">
								<!-- <ol class="comment-list">
									<li class="comment">
										<article class="comment-body">
											<div class="comment-avatar">
												<img src="img/rs-avatar-64x64.jpg" alt="avatar"/>
											</div>
											<div class="comment-content">
												<div class="comment-meta">
													<span class="name">Jane Doe</span>
													<time class="date" datetime="2015-03-20T13:00:14+00:00">March 20, 2015 at 1:00 pm</time>
													<a class="reply-link" href="single-dailymotion.html#comment-reply">Reply</a>
												</div>
												<div class="comment-message">
													<p>Lorem ipsum dolor sit aum nulla quis nesciunt ipsa aliquam aliquid eum, voluptatibus
														assumenda minima vel. Eaque, velit architecto error ducimus aliquid.</p>
												</div>
											</div>
										</article> -->
<!-- 
										<ol>
											<li class="comment">
												<article class="comment-body">
													<img class="comment-avatar" src="img/rs-avatar-64x64.jpg" alt="avatar"/>
													<div class="comment-content">
														<div class="comment-meta">
															<span class="name">Jane Doe</span>
															<time class="date" datetime="2015-03-20T13:00:14+00:00">March 20, 2015 at 1:00 pm</time>
															<a class="reply-link" href="single-dailymotion.html#comment-reply">Reply</a>
														</div>
														<div class="comment-message">
															<p>Lorem ipsum dolor sit aum nulla quis nesciunt ipsa aliquam aliquid eum, voluptatibus
																assumenda minima vel. Eaque, velit architecto error ducimus aliquid.</p>
														</div>
													</div>
												</article>

												<ol>
													<li class="comment">
														<article class="comment-body">
															<img class="comment-avatar" src="img/rs-avatar-64x64.jpg" alt="avatar"/>
															<div class="comment-content">
																<div class="comment-meta">
																	<span class="name">Jane Doe</span>
																	<time class="date" datetime="2015-03-20T13:00:14+00:00">March 20, 2015 at 1:00 pm</time>
																	<a class="reply-link" href="single-dailymotion.html#comment-reply">Reply</a>
																</div>
																<div class="comment-message">
																	<p>Lorem ipsum dolor sit aum nulla quis nesciunt ipsa aliquam aliquid eum, voluptatibus
																		assumenda minima vel. Eaque, velit architecto error ducimus aliquid.</p>
																</div>
															</div>
														</article> -->
													<!-- </li> --><!-- .comment (level 3) -->
												<!-- </ol> --><!-- .comment-list (level 3) -->
											<!-- </li> --><!-- .comment (level 2) -->
										<!-- </ol> --><!-- .comment-list (level 2) -->
									<!-- </li> --><!-- .comment -->
	
									
									<?php foreach($data as $value) {?>

									
                                  <ol class="comment-list">
									<li class="comment">
										<article class="comment-body">
											<img class="comment-avatar" src="img/rs-avatar-64x64.jpg" alt="avatar"/>
											<div class="comment-content">
												<div class="comment-meta">
													<span class="name"><?php echo $value['username']; 
													//var_dump($data);?></span>
													<!-- <time class="date" datetime="2015-03-20T13:00:14+00:00">March 20, 2015 at 1:00 pm</time> -->
													<time class="date" > <?php echo  date('d M Y h:i:s A',$value['createddate']); ?> </time>
													<a class="reply-link" href="single-dailymotion.php#comment-reply">Reply</a>
												</div>
												<div class="comment-message">
													<p><!-- Lorem ipsum dolor sit aum nulla quis nesciunt ipsa aliquam aliquid eum, voluptatibus
														assumenda minima vel. Eaque, velit architecto error ducimus aliquid. -->
														<?php echo $value['comment'];?></p>
												</div>
											</div>
										</article>
									</li><!-- .comment -->
								</ol><!-- .comment-list -->
                              <?php }?>
								<div id="comment-reply" class="comment-reply">
									<form id="commentform">
										<div class="input-field">
											<input type="text" name="rs-comment-name"/>
											<span class="line"></span>
											<label>Name *</label>
										</div>

										<div class="input-field">
											<input type="email" name="rs-comment-email"/>
											<span class="line"></span>
											<label>Email *</label>
										</div>

										<div class="input-field">
											<input type="text" name="rs-comment-website"/>
											<span class="line"></span>
											<label>Website</label>
										</div>

										<div class="input-field">
											<textarea rows="4" name="rs-comment-message"></textarea>
											<span class="line"></span>
											<label>Type Comment Here *</label>
										</div>

										<div class="text-right">
											<span class="btn-outer btn-primary-outer ripple">
												<input class="btn btn-lg btn-primary" type="submit" name="submit" value="Leave Comment">
											</span>
										</div>
									</form>
								</div><!-- .comment-reply -->
							</div><!-- .section-box -->
						</div><!-- .post-comments -->
					</main>
					<!-- .post-single -->
				</div>

				<div class="col-sm-4">
					<div class="sidebar sidebar-default">
						<div class="widget-area">
							<aside class="widget widget-profile">
								<div class="profile-photo">
									<img src="img/uploads/rs-photo-v2.jpg" alt="Robert Smith"/>
								</div>
								<div class="profile-info">
									<h2 class="profile-title">Robert Smith</h2>
									<h3 class="profile-position">Developer and businessman</h3>
								</div>
							</aside><!-- .widget-profile -->

							<aside class="widget widget_search">
								<h2 class="widget-title">Search</h2>
								<form class="search-form">
									<label class="ripple">
										<span class="screen-reader-text">Search for:</span>
										<input class="search-field" type="search" placeholder="Search">
									</label>
									<input type="submit" class="search-submit" value="Search">
								</form>
							</aside><!-- .widget_search -->

							<aside class="widget widget_contact">
								<h2 class="widget-title">Contact Me</h2>
								<form class="contactForm" action="php/contact_form.php" method="post">
									<div class="input-field">
										<input class="contact-name" type="text" name="name" id="name"/>
										<span class="line"></span>
										<label>Name</label>
									</div>

									<div class="input-field">
										<input class="contact-email" type="email" name="email" id="email"/>
										<span class="line"></span>
										<label>Email</label>
									</div>

									<div class="input-field">
										<input class="contact-subject" type="text" name="subject" id="subject"/>
										<span class="line"></span>
										<label>Subject</label>
									</div>

									<div class="input-field">
										<textarea class="contact-message" rows="4" name="message" id="message"></textarea>
										<span class="line"></span>
										<label>Message</label>
									</div>

									<span class="btn-outer btn-primary-outer ripple">
										<input class="contact-submit btn btn-lg btn-primary" type="submit" value="Send"/>
									</span>
									
									<div class="contact-response"></div>
								</form>
							</aside><!-- .widget_contact -->

							<aside class="widget widget-popuplar-posts">
								<h2 class="widget-title">Popular posts</h2>
								<ul>
									<li>
										<div class="post-media"><a href=""><img src="img/uploads/thumb-78x56-1.jpg" alt=""/></a></div>
										<h3 class="post-title"><a href="">Standard Post Format With Featured Image</a></h3>
										<div class="post-info"><a href=""><i class="icon icon-comments"></i>56 comments</a></div>
									</li>
									<li>
										<div class="post-media"><a href=""><img src="img/uploads/thumb-78x56-2.jpg" alt=""/></a></div>
										<h3 class="post-title"><a href="">Standard Post Format With Featured Image</a></h3>
										<div class="post-info"><a href=""><i class="icon icon-comments"></i>56 comments</a></div>
									</li>
									<li>
										<div class="post-media"><a href=""><img src="img/uploads/thumb-78x56-3.jpg" alt=""/></a></div>
										<h3 class="post-title"><a href="">Standard Post Format With Featured Image</a></h3>
										<div class="post-info"><a href=""><i class="icon icon-comments"></i>56 comments</a></div>
									</li>
								</ul>
							</aside><!-- .widget-popuplar-posts -->

							<aside class="widget widget_tag_cloud">
								<h2 class="widget-title">Tag Cloud</h2>
								<div class="tagcloud">
									<a href="" title="1 topic">Business</a>
									<a href="" title="9 topics">City</a>
									<a href="" title="10 topics">Creative</a>
									<a href="" title="6 topics">Fashion</a>
									<a href="" title="2 topics">Music</a>
									<a href="" title="5 topics">News</a>
									<a href="" title="9 topics">Peoples</a>
								</div>
							</aside><!-- .widget_tag_cloud -->

							<aside class="widget widget-recent-posts">
								<h2 class="widget-title">Recent posts</h2>
								<ul>
									<li>
										<div class="post-tag">
											<a href="">#Photo</a>
											<a href="">#Architect</a>
										</div>
										<h3 class="post-title"><a href="">Standard Post Format With Featured Image</a></h3>
										<div class="post-info"><a href=""><i class="icon icon-comments"></i>56 comments</a></div>
									</li>
									<li>
										<div class="post-tag">
											<a href="">#Photo</a>
											<a href="">#Architect</a>
										</div>
										<h3 class="post-title"><a href="">Standard Post Format With Featured Image</a></h3>
										<div class="post-info"><a href=""><i class="icon icon-comments"></i>56 comments</a></div>
									</li>
									<li>
										<div class="post-tag">
											<a href="">#Photo</a>
											<a href="">#Architect</a>
										</div>
										<h3 class="post-title"><a href="">Standard Post Format With Featured Image</a></h3>
										<div class="post-info"><a href=""><i class="icon icon-comments"></i>56 comments</a></div>
									</li>
								</ul>
							</aside><!-- .widget-recent-posts -->

							<aside class="widget widget_categories">
								<h2 class="widget-title">Categories</h2>
								<ul>
									<li><a href="" title="Architecture Category Posts">Architecture</a> (9)</li>
									<li><a href="" title="Business Category Posts">Business</a> (16)</li>
									<li><a href="" title="Creative Category Posts">Creative</a> (18)</li>
									<li><a href="" title="Design Category Posts">Design</a> (10)</li>
									<li><a href="" title="Development Category Posts">Development</a> (14)</li>
									<li><a href="" title="Education Category Posts">Education</a> (9)</li>
								</ul>
							</aside><!-- .widget_categories -->
						</div><!-- .widget-area -->
					</div><!-- .sidebar -->
				</div><!-- .col-sm-4 -->
			</div><!-- .row -->			
			<!-- END: PAGE CONTENT -->
                
            </div><!-- .container -->
        </div><!-- .content -->

        <footer class="footer">
            <div class="footer-social">
                <ul class="social">
					<li><a class="ripple-centered" href="https://www.facebook.com/punit.kumar.31"><i class="icon icon-facebook"></i></a></li>
					<li><a class="ripple-centered" href=""><i class="icon icon-twitter"></i></a></li>
					<li><a class="ripple-centered" href=""><i class="icon icon-linkedin"></i></a></li>
					<li><a class="ripple-centered" href=""><i class="icon icon-google-plus"></i></a></li>
					<li><a class="ripple-centered" href=""><i class="icon icon-dribbble"></i></a></li>
					<li><a class="ripple-centered" href=""><i class="icon icon-instagram"></i></a></li>
				</ul>
            </div>
        </footer><!-- .footer -->
    </div><!-- .wrapper -->
	
	<a class="btn-scroll-top" href="single-dailymotion.php#"><i class="icon icon-arrow-up"></i></a>
    <div id="overlay"></div>
    <div id="preloader"></div>

    <!-- Scripts -->
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.js"></script>
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>
    <script type="text/javascript" src="js/site.min.js"></script>
    <script type="text/javascript" src="js/jquery.validate.min.js"></script>
</body>
<script>
$('document').ready(function(){
	$('#commentform').validate({
		rules:{
			name:{
				required:true,
			},
			email:{
				required:true,
				email:true
			},
			subject:{
				required:true,
			},
			message:{
				required:true
			},
		},
		submitHandler:function(){
			$.ajax({
				url:'ajax/save_comment.php',
                data:$('#commentform').serialize(),
                type:'post',
                success:function(res){
                	console.log(res);
                    $('#commentform').trigger('reset');
                	window.location.reload();


                }
			})
		}
	});

})
</script>
<script src="https://repository.chatwee.com/scripts/fb0bf687c2a98f10028a27a18368efbe.js" type="text/javascript" charset="UTF-8"></script>
</html>