<?php 

$opportunityStatus = array("1"=>"Fresh", "2"=>"Qualified", "3"=>"Requirement Gathering", "4"=>"Proposal Sent", "5"=>"Won", "6"=>"Closed", "7"=>"Rejected");
function getChildCategory($parent, $catId, $parentId){
    $child="SELECT * FROM tbl_product_category where parentid=:parent and identifier!=:id";
	$core=Core::getInstance();
	$reschild=$core->dbh->prepare($child);
	$reschild->execute(array(':parent'=>$parent, ':id'=>$catId));
	if($reschild->rowCount()){
		$i++;
		while($recchild=$reschild->fetch(PDO::FETCH_ASSOC)){
			if($recchild['identifier'] == $parentId)
				$selected = 'selected="selected"';
			else
				$selected = "";
			echo '<option value="'.$recchild['identifier'].'" '.$selected.'>';
			$j=0;
			while($j<$i){
				echo '--';
				$j++;
			}
			
			echo $recchild['label'].'</option>';
			
			getChildCategory($recchild['identifier'], $catId, $parentId);
			
		}
	}
	else{
		return;
	}	 
}

function recursiveCall($parent){
	$child="SELECT * FROM tbl_menu where parentid=:parent ORDER BY ordering ASC";
	$core=Core::getInstance();
	$reschild=$core->dbh->prepare($child);
	$reschild->execute(array(':parent'=>$parent));
	if($reschild->rowCount()){
		echo '<ol class="dd-list">';
		while($recchild=$reschild->fetch(PDO::FETCH_ASSOC)){
			echo '<li data-id="'.$recchild['id'].'" class="dd-item">
				<div class="dd-handle">'.$recchild['label'].'</div>
				<div class="menuOption">
                      <a href="#editBox" title="Edit" class="fancybox"><span class="editMenu fa fa-edit" rel="'.$recchild['label'].'" id="menuid_'.$recchild['id'].'"><span></a> | 
                      <a title="Delete" href="javascript:void(0)"><span class="deleteMenu fa fa-trash" id="menu_'.$recchild['id'].'"><span></a>
                </div>';
			recursiveCall($recchild['id']);	
			echo "</li>";
		}
		echo '</ol>';
	}
	else{
		return;
	}	
}

function recursiveMenu($id, $i, $parent){
	$child="SELECT * FROM tbl_menu where parentid=:parent";
	$core=Core::getInstance();
	$reschild=$core->dbh->prepare($child);
	$reschild->execute(array(':parent'=>$id));
	if($reschild->rowCount()){
		$i++;
		while($recchild=$reschild->fetch(PDO::FETCH_ASSOC)){
			if($recchild['identifier'] == $parent)
				$selected = 'selected="selected"';
			else
				$selected = "";
			echo '<option value="'.$recchild['identifier'].'" '.$selected.'>';
			$j=0;
			while($j<$i){
				echo '--';
				$j++;
			}
			
			echo $recchild['label'].'</option>';
			
			recursiveMenu($recchild['identifier'], $i, $parent);
			
		}
	}
	else{
		return;
	}	
}

function addData($table, $contentData) {
	$content = array();
	$column = "";
	$columnKey = "";
	$tableData = "";
	foreach($contentData as $key=>$data){
		$content[':'.$key] = $data;
		
		//DATA CONTENT 
		$tableData = $tableData."'".$data."',";
		
        $column = $column."`".$key."`".",";
		$columnKey = $columnKey.":".$key.",";
	}
	$columnKey = rtrim($columnKey, ",");
	$column = rtrim($column, ",");
	$tableData = rtrim($tableData, ",");
	$column = "(".$column.")";
	$columnKey = "(".$columnKey.")";
	$insert = "INSERT INTO ".$table." ".$column." VALUES ".$columnKey;
	$core = Core::getInstance();
	$result = $core->dbh->prepare($insert);
	$result->execute($content);
	$lastId = $core->dbh->lastInsertId();
	return $lastId;
}

function addLogData($table, $query){
	$contentArray = array(":table"=>$table, ":query"=>$query, ":created"=>time());
	$insert = "INSERT INTO tbl_query (tablename, query, createdon) values (:table, :query, :created)";
	$core = Core::getInstance();
	$result = $core->dbh->prepare($insert);
	$result->execute($contentArray);
}

function updateData($table, $contentData, $column, $id){
	$content = array();
	$columnKey = "";
	$tableData = "";
	foreach($contentData as $key=>$data){
		$content[':'.$key] = $data;
		$columnKey = $columnKey."`".$key."`"."=:".$key.",";
		$tableData = $tableData."`".$key."`"."='".$data."',";
	}
	$columnKey = rtrim($columnKey, ",");
	$tableData = rtrim($tableData, ",");
	
	$updateQuery = "UPDATE ".$table." SET ".$tableData." WHERE ".$column."='".$id."'";
	
	//add log data	
	
	$update = "UPDATE ".$table." SET ".$columnKey." WHERE ".$column."=:".$column;
	$content[':'.$column] = $id;
	$core = Core::getInstance();
	$result = $core->dbh->prepare($update);
	$result->execute($content);
	$lastId = $id;
	return $lastId;
}

function updateDataMulti($table, $contentData, $whereQuery){
	$content = array();
	$wherequery = " WHERE ";
	$whereQ = " WHERE ";
	$columnKey = "";
	$tableData = "";
	foreach($contentData as $key=>$data){
		$content[':'.$key] = $data;
		$columnKey = $columnKey."`".$key."`"."=:".$key.",";
		$tableData = $tableData."`".$key."`"."='".$data."',";
	}
	
	foreach($whereQuery as $key=>$data){
		$wherequery = $wherequery." ";
		$whereQ = $whereQ." ";
		$count = 0;
		foreach($data as $key1=>$value1){
			if($count == "0"){
				$wherequery = $wherequery. "`".$key1."`=:".$key1;
				$whereQ = $whereQ. "`".$key1."`=".$value1;
			}else{
				$wherequery = $wherequery. " $key `".$key1."`=:".$key1;
				$whereQ = $whereQ. " $key `".$key1."`=".$value1;
			}
			$content[':'.$key1] = $value1;
			$count++;
		}
	}
	
	$columnKey = rtrim($columnKey, ",");
	$tableData = rtrim($tableData, ",");
	
	$updateQuery = "UPDATE ".$table." SET ".$tableData.$whereQ;
	
	//add log data
	addLogData($table, $updateQuery);
	
	$update = "UPDATE ".$table." SET ".$columnKey.$wherequery;
	
	$core = Core::getInstance();
	
	$result = $core->dbh->prepare($update);
	$result->execute($content);
	$lastId = $id;
	return $lastId;
}


function fetchData($query, $array=array(), &$totalCount){
	$select = $query;
	$core = Core::getInstance();
	$result = $core->dbh->prepare($select);
	$result->execute($array);
    $totalCount = $result->rowCount();
	$dataRecord = array();
	while($record = $result->fetch(PDO::FETCH_ASSOC)){
		array_push($dataRecord, $record);
	}
	return $dataRecord;
}

function countData($query, &$totalCount, $array = array()){
	$select = $query;
	$core = Core::getInstance();
	$result = $core->dbh->prepare($select);
	$result->execute($array);
	$totalCount = $result->rowCount();
}
function currentUser(){
	global $_SESSION;
	$returnArray = array();
	$userid = $_SESSION['admin']['identifier'];
	$query = "SELECT * FROM tbl_users WHERE identifier = :id";
	$counter = 0;
	$data = fetchData($query,array(':id'=>$userid),$counter);
	$returnArray['userData'] = $data[0];
	return $returnArray;
}
function get_media_name($id)
{
    $name = "";
	$select = "SELECT * FROM tbl_media WHERE identifier = :id LIMIT 0,1";
    $core = Core::getInstance();
    $result = $core->dbh->prepare($select);
    $result->execute(array(":id"=>$id));
    $count = $result->rowCount();
    if($count)
    {
        $row = $result->fetch(PDO::FETCH_ASSOC);
        $name = $row['path'];			
    }
    return $name;
}
function delete($table, $contentData){	
    $i = 0;
	$where = "";
	$content = array();
    
	foreach($contentData as $key=>$data){
		$content[':'.$key] = $data;
		if($i == 0)
			$where = $where." WHERE ".$key."=:".$key;
		else
			$where = $where." AND ".$key."=:".$key;
		$i++;
	}    
	$query = "DELETE FROM ".$table.$where;	
	$core = Core::getInstance();
	$result = $core->dbh->prepare($query);
	$result->execute($content);
}
function checkShortcode($content, &$shortCodes){
    //$regex = "/\[\[([a-zA-Z\]\]]+)]/";
    $regex = "/\[\[([a-zA-Z]+)\]\]/";
    $restContent = preg_split($regex, $content);
    preg_match_all($regex, $content, $shortCodes);
    return $restContent;
}
function formatFileName($value)
{
	$text = preg_replace('~[^\\pL\d]+~u', '-', $value);
	$text = trim($text, '-');
	$text = strtolower($text);
	$text = preg_replace('~[^-\w]+~', '', $text);
	return $text;
}
function login($post){
	$email  	= $post['email'];
	$password  	= $post['password'];
	$query  = "SELECT * FROM tbl_users WHERE email = :email AND password = :password";
	$counter = 0;
	$data = fetchData($query,array(),$counter);
	return $counter ? true : false;
}
function createPassword($length= 8){
    $pass = '';
    $array = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm','n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z','1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
    for($i=0; $i<$length; $i++){
        $rand = rand(0, 35);
        $pass = $pass.$array[$rand];
    }
    return $pass;
}
function sendpasswordmail($password,$name,$email){
    $mailBody   =   file_get_contents('emailer/forgot.html');
    $mailBody   =   str_replace("[Name]", $name, $mailBody);
    $mailBody   =   str_replace("[Email]", $email, $mailBody);
    $mailBody   =   str_replace("[Password]", $password, $mailBody);        
    $subject    =   "Forgot Password";
    $headers    =   'MIME-Version: 1.0' . "\r\n";    
    $headers   .=   'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers   .=   'From: Dynakode CRM <no-reply@dynakode.com>' . "\r\n";    
    $mail       =    mail($email, $subject, $mailBody, $headers);    
}
function checkEmail($email,$id){
	$query = "select email from tbl_user WHERE email = :email ";
	if($id){
		$query .= " AND identifier != $id";
	}
	$counter = 0;
	$data   = fetchData($query,array(':email'=>$email),$counter);
	return $counter ? true : false;
}

function signupUser($post){
	global $_SESSION;
	$table = "tbl_users";
	$contentdata = array();
	$contentData['name'] 		= 	$post['name'];
	$contentData['email'] 		= 	$post['email'];
	$contentData['phone'] 		= 	$post['phone'];
	$contentData['type'] 		= 	$post['type'];
	$contentData['deleted'] 	= 	"0";
	$contentData['createdon'] 	= 	time();	
	if($type=="3")
	{
		$contentData['status'] = "0";
	}
	else
	{
		$contentData['status'] = "1";
	}
	$query = "select email, phone from tbl_users where email=:email OR phone=:phone";
	$counter = 0;
	$data = fetchData($query,array(':email'=>$post['email'],':phone'=>$post['phone']),$counter);
	if(!$counter)
	{
		$userid = addData($table, $contentData); 
		$_SESSION['user']['identifier'] = $userid;
		$_SESSION['user']['email'] 		= $contentData['email'];
		$_SESSION['user']['name'] 		= $contentData['name'];
		$_SESSION['user']['type'] 		= $contentData['type'];
		return true;		
	}
	else
	{
		return false;
	}	
}
function getConfValue($metakey){
    $metaValue = "";
    $select = "SELECT * FROM tbl_config where metakey=:key";
    $core = Core::getInstance();
    $result = $core->dbh->prepare($select);
    $result->execute(array(':key'=>$metakey));
    if($result->rowCount()){
        $record = $result->fetch(PDO::FETCH_ASSOC);
        $metaValue = $record['metavalue'];
    }
    return $metaValue;
}
function getBillingStatus($publication){
	global $_SESSION;
	$flag = 0;
	$disid = $_SESSION['user']['identifier'];
	$query = "SELECT time,frequency FROM tbl_bills WHERE distributorid = :disid AND publicationid = :pubid ORDER BY identifier DESC LIMIT 1";
	$counter = 0;
	$data = fetchData($query,array(':disid'=>$disid,':pubid'=>$publication['identifier']),$counter);
	if($counter){
		$frequency = $publication['freq'];
		foreach($data as $statusdata){
			
			$time = $statusdata['time'];
			if($frequency == 'Daily'){
				if(date('dmY') == date('dmY',$time)){
					$flag = 1;
				}
			} 
			else if($frequency == 'Weekly'){
				if(date('W',$time) == date('W') ){
					$flag = 1;
				}
			}
			else if($frequency == 'Forthnightly'){
				if((date('W',$time)-(date('W')) ) < 2){
					$flag = 1;
				}
			}
			else if($frequency == 'Monthly'){
				if(date('mY') == date('mY',$time)){
					$flag = 1;
				}
			}
			else if($frequency == 'Bimonthly'){
				if((date('m',$time)-(date('m')) ) < 2){
					$flag = 1;
				}
			}
			else if($frequency == 'Quarterly'){
				if((date('m',$time)-(date('m')) ) < 4){
					$flag = 1;
				}
			}
		}
	}
	return $flag;
}
function getLastGenerateTime($publicationid){	
	global $_SESSION;
	$disid = $_SESSION['user']['identifier'];
	$query = "SELECT time FROM tbl_bills WHERE distributorid = :disid AND publicationid = :pubid ORDER BY identifier DESC LIMIT 1";
	$counter = 0;
	$data = fetchData($query,array(':disid'=>$disid,':pubid'=>$publicationid),$counter);
	return $counter ? $data[0]['time'] : 0;
}

function getAllPublication(){
	$query = "SELECT * FROM tbl_publication WHERE deleted = 0 AND status = 1";
	$counter = 0;
	$data = fetchData($query,array(),$counter);
	return $data;
}
function getAllReaders($userid = 0){
	if(!$userid){
		global $_SESSION;
		$userid = $_SESSION['user']['identifier'];
	}
	$query = "SELECT * from tbl_readers WHERE userid = :id";
	$counter = 0;
	$data =  fetchData($query,array(':id'=>$userid),$counter);
	return $data;
}
function time_elapsed_string($ptime)
{
    $etime = time() - $ptime;
    if ($etime < 1)
    {
        return '0 seconds';
    }
    $a = array( 365 * 24 * 60 * 60  =>  'year',
                 30 * 24 * 60 * 60  =>  'month',
                      24 * 60 * 60  =>  'day',
                           60 * 60  =>  'hour',
                                60  =>  'minute',
                                 1  =>  'second'
                );
    $a_plural = array( 'year'   => 'years',
                       'month'  => 'months',
                       'day'    => 'days',
                       'hour'   => 'hours',
                       'minute' => 'minutes',
                       'second' => 'seconds'
                );

    foreach ($a as $secs => $str)
    {
        $d = $etime / $secs;
        if ($d >= 1)
        {
            $r = round($d);
            return $r . ' ' . ($r > 1 ? $a_plural[$str] : $str) . ' ago';
        }
    }
}
function slugify($value)
{
// replace non letter or digits by -
$text = preg_replace('~[^\\pL\d]+~u', '-', $value);
// trim
$text = trim($text, '-');

// transliterate
//$text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

// lowercase
$text = strtolower($text);

// remove unwanted characters
$text = preg_replace('~[^-\w]+~', '', $text);

if (empty($text))
{
return 'n-a';
}
 $handle = findhandle($text); 
 return $handle;
}

function findhandle($text)
{
	$query  =   "SELECT handle FROM tbl_slug WHERE handle LIKE '$text' LIMIT 1";
    $array = array();
    $counter = 0;
	$data  = fetchData($query, $array, $counter);
	if(count($data))
	{	
		foreach($data as $handledata)
		{
			$handle 	= $handledata['handle'];
			$lastChar 	= intval(substr($handle, -1));
			if($lastChar > 0 )
			{
				$handle = rtrim($handle,$lastChar);
				$lastChar = $lastChar+1;			
				$handle .= '-'.$lastChar;
				$handle = str_replace('--','-', $handle);
				return findhandle($handle); 
			}
			else
			{ 
				$handle .= '-1';
				return findhandle($handle);
			}
		}
	}
	else
	{
		return strtolower($text);
	}
}

function getCustomFields($proid){
    $query = "SELECT CV.customvalue,CF.label,CF.options,CF.field_type,CF.identifier FROM tbl_custom_values CV JOIN tbl_custom_field CF ON CV.fieldid = CF.identifier WHERE CV.productid = :proid";
    $counter = 0;
    $returnData = '';
    $data = fetchData($query,array(':proid'=>$proid),$counter);
    if($counter){
        foreach($data as $customData){
            if($customData['field_type'] == 'text'){
                $returnData .= '<div class="form-group">
                                    <label class="form-label">'.$customData["label"].'</label>  
                                    <div class="controls">
                                        <input type="text" class="form-control" placeholder="'.$customData["label"].'" value="'.$customData["customvalue"].'" name="customfield['.$customData["identifier"].']">
                                    </div>
                                </div>';
            }
           /*if($customData['field_type'] == 'selectbox'){
                $returnData .= '<div class="form-group">
                                <label class="form-label">'.$customData["label"].'</label>  
                                <div class="controls">
                                    <select name="customfield['.$customData["customvalue"].']" class="form-control chosen-select">
                                    '.$customData["options"].'
                                    </select>
                                </div>
                            </div>';
            }*/
        }
    }
    return $returnData;
}

function getCustomFieldByCat($catId, $proId){
	$query = "select CF.*, coalesce(CV.customvalue, '') as customvalue from tbl_custom_field CF left join (select fieldid, customvalue from tbl_custom_values where productid=:pro) CV on CV.fieldid=CF.identifier where CF.categoryid=:cat order by CF.ordering asc, CF.label asc, if(CV.customvalue = '' or CV.customvalue is null,1,0),CV.customvalue desc";
	$array = array(":cat"=>$catId, ":pro"=>$proId);
	$count = 0;
	$returnData = "";
	$data = fetchData($query, $array, $count);
	if($count){
        foreach($data as $customData){
            if($customData['field_type'] == 'text'){
                $returnData .= '<div class="form-group">
                                    <label class="form-label">'.$customData["label"].'</label>  
                                    <div class="controls">
                                        <input type="text" class="form-control" placeholder="'.$customData["label"].'" value="'.$customData['customvalue'].'" name="customfield['.$customData['identifier'].']">
                                    </div>
                                </div>';
            }
        }
    }
	return $returnData;
}
function checkConnect($address,$port,$name)  {
   if (isset($port) and
      ($socket=socket_create(AF_INET, SOCK_STREAM, SOL_TCP)) and
      (socket_connect($socket, $address, $port)))
    {    
      $text='1';
      socket_close($socket);
    }
   else
  {     
  	 $text = "0";
  }
  return $text;    	
 }
function getEmailData($deviceArray){
  $table = '<table border="1" cellpadding="5" rules="all">
            <tr>
              <th>Name</th>
              <th>IP</th>
              <th>Port</th>              
              <th>Current Status</th>
            </tr>';
  for($i = 0; $i < count($deviceArray['description']);$i++){
    $table .=  '<tr>
                  <td>'.$deviceArray['description'][$i].'</td>
                  <td>'.$deviceArray['ip'][$i].'</td>
                  <td>'.$deviceArray['port'][$i].'</td>                 
                  <td>'.$deviceArray['status'][$i].'</td>
                </tr>';
  }
   $table .= "</table>"  ;
   return $table;
}
function getOwnerUser(){
  $query = "SELECT name,identifier FROM tbl_user WHERE role = '2' ORDER BY name ASC";
  $counter=  0;  
  $data = fetchData($query,array(),$counter);
  return $data;
}
function checkCompanyName($name,$id=0){
	$query = "SELECT name FROM tbl_company WHERE name = :name ";
	if($id){
		$query .= " AND identifier != $id ";
	}
	$counter = 0;		
	$data  = fetchData($query,array(':name'=>$name),$counter);
	return $counter ? true : false;
}
function getCompanyOwners($companyid){
  $query = "SELECT group_concat(U.name SEPARATOR ', ') as ownernames FROM tbl_company_owner CO JOIN tbl_user U ON U.identifier = CO.ownerid WHERE CO.companyid = :id";
  $counter = 0;
  $data = fetchData($query, array(':id'=>$companyid),$counter);
  return $data;
}
function getOwnersCompany($ownerid){
	$query = "SELECT group_concat(C.name SEPARATOR ', ') as companyname FROM tbl_company_owner CO JOIN tbl_company C ON C.identifier = CO.companyid WHERE CO.ownerid = :id";
  $counter = 0;
  $data = fetchData($query, array(':id'=>$ownerid),$counter);
  return $data;	
}
function getCustomerContacts($id){
  $query = "SELECT * FROM tbl_contacts WHERE customerid = :id ORDER BY identifier DESC";
  $counter = 0;
  $data = fetchData($query,array(':id'=>$id),$counter);
  return $data;
}
function getAllCustomerContacts(){
  $query = "SELECT CO.identifier,C.name,CO.name as contactname FROM `tbl_customer` C JOIN tbl_contacts CO ON CO.customerid = C.identifier ORDER BY C.name ASC, CO.name ASC";
  $counter = 0;  
  $data = fetchData($query,array(),$counter );
  return $data;
}
function getCompanyUsers(){
  global $_SESSION;
  $session_company = $_SESSION['user']['company'];
  $query = "SELECT name, identifier FROM tbl_user WHERE identifier IN (SELECT userid FROM `tbl_company_users` WHERE companyid = :company) ORDER BY name ASC";
  $counter = 0;  
  $data = fetchData($query,array(':company'=>$session_company),$counter );
  return $data; 
}
 function getUserCompanyID(){
    global $_SESSION;
    if($_SESSION['user']['role'] == 'user'){
      $query = "SELECT companyid FROM tbl_company_users WHERE userid = :id";
      $counter = 0;
      $data = fetchData($query,array(':id'=>$_SESSION['user']['id']),$counter);
      return $counter ? $data[0]['companyid'] : 0;
    }
    if($_SESSION['user']['role'] == 'owner'){
       $query = "SELECT identifier,name FROM tbl_company WHERE identifier IN (SELECT companyid FROM tbl_company_owner WHERE ownerid = :id) ORDER BY name ASC";      
      $counter = 0;
      $data = fetchData($query,array(':id'=>$_SESSION['user']['id']),$counter);      
      return $counter ? $data[0]['identifier'] : 0;
    }
  }
function getUserCompanies(){
  global $_SESSION;                                    
  $query = "SELECT C.* FROM tbl_company_owner CO JOIN tbl_company C ON CO.companyid = C.identifier WHERE CO.ownerid = :owner";
  $counter = 0;
  $data = fetchData($query, array(':owner'=>$_SESSION['user']['id']), $counter);
  return $data;
}

function getUserEmail($id){
	$select = "select * from tbl_user where identifier=:id";
	$core = Core::getInstance();
	$result = $core->dbh->prepare($select);
	$result->execute(array(":id"=>$id));
	$record = $result->fetch(PDO::FETCH_ASSOC);
	return $record;
}

function getOpportunityDetail($oppId){
	$query = "select * from tbl_opportunity WHERE identifier=:id";
	$count = 0;
	$data = fetchData($query, array(":id"=>$oppId), $count);
	if($count){
		return $data[0];
	}else{
		return array();
	}
}

function getOpportunityMail($oppId){
	global $_SESSION;
	$emails = array();
	$select = "SELECT U.* FROM tbl_opportunity O JOIN tbl_company_owner CO on CO.companyid=O.companyid JOIN tbl_user U on U.identifier=CO.ownerid where O.identifier=:id and U.identifier!=:userid";
	$counter = 0;
	$data = fetchData($select, array(":id"=>$oppId, ":userid"=>$_SESSION['user']['idnetifier']), $counter);
	foreach($data as $email){
		array_push($emails, $email['email']);
	}

	$oppDetails = getOpportunityDetail($oppId);
	if(count($oppDetails)){
		if($oppDetails['assigned_to'] != $_SESSION['user']['identifier']){
			$assignEmailData = getUserEmail($oppDetails['assigned_to']);
			array_push($emails, $assignEmailData['email']);
		}
	}
	return $emails;
}

function timeAgo($ptime) {
    $etime = time() - $ptime;
    
    if ($etime < 1) {
        return '0 seconds';
    }
    
    $a = array( 12 * 30 * 24 * 60 * 60  =>  'year',
                30 * 24 * 60 * 60       =>  'month',
                24 * 60 * 60            =>  'day',
                60 * 60                 =>  'hour',
                60                      =>  'minute',
                1                       =>  'second'
                );
    
    foreach ($a as $secs => $str) {
        $d = $etime / $secs;
        if ($d >= 1) {
            $r = round($d);
            return $r . ' ' . $str . ($r > 1 ? 's' : '');
        }
    }
}
?>